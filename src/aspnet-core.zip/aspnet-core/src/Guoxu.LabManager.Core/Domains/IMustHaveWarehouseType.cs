﻿namespace Guoxu.LabManager.Domains;

public interface IMustHaveWarehouseType
{
     WarehouseType WarehouseType { get; set; }
}