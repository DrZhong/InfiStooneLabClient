﻿using System.ComponentModel.DataAnnotations;
namespace Guoxu.LabManager.Organization.Dto
{
    public class MoveOrganizationUnitInput
    {
        [Range(1, long.MaxValue)]
        public long Id { get; set; }

        public long? NewParentId { get; set; }
    }
}