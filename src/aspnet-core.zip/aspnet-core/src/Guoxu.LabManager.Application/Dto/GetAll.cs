﻿namespace Guoxu.LabManager.Dto
{
    public class GetAll
    {
        
    }
}

